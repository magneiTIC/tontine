<?php

namespace Config;


use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\Honeypot;
use CodeIgniter\Filters\InvalidChars;
use CodeIgniter\Filters\SecureHeaders;
use CodeIgniter\Session\Session;
use App\Filters\MembreFilter;
use App\Filters\AdherentFilter;
use App\Filters\AdministrateurFilter;




class Filters extends BaseConfig
{
    /**
     * Configures aliases for Filter classes to
     * make reading things nicer and simpler.
     *
     * @var array
     */
    public $aliases = [
        'csrf'          => CSRF::class,
        'toolbar'       => DebugToolbar::class,
        'honeypot'      => Honeypot::class,
        'invalidchars'  => InvalidChars::class,
        'secureheaders' => SecureHeaders::class,
        'secureheaders' => SecureHeaders::class,
        'membreFilter' => MembreFilter::class,
        'adherentFilter' => AdherentFilter::class,
        'administrateurFilter' => AdministrateurFilter::class,



    ];

    /**
     * List of filter aliases that are always
     * applied before and after every request.
     *
     * @var array
     */
    public $globals = [
        'before' => [
            // 'honeypot',
            // 'csrf',
            // 'invalidchars',
        ],
        'after' => [
            'toolbar',
            // 'honeypot',
            // 'secureheaders',
        ],
    ];

    /**
     * List of filter aliases that works on a
     * particular HTTP method (GET, POST, etc.).
     *
     * Example:
     * 'post' => ['csrf', 'throttle']
     *
     * @var array
     */
    public $methods = [];

    /**
     * List of filter aliases that should run on any
     * before or after URI patterns.
     *
     * Example:
     * 'isLoggedIn' => ['before' => ['account/*', 'profiles/*']]
     *
     * @var array
     */
    public $filters = [
        'membreFilter' =>['before' => ['adherent','adherent/*'],
                                     ['administrateur','administrateur/*']   
    ],
        'adherentFilter' =>['before' => ['adherent','adherent/*'],],
        'administrateurFilter'=>['before' => ['administrateur','administrateur/*'],],
    ];
}
